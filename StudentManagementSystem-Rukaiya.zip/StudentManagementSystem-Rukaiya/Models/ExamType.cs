﻿namespace StudentManagementSystem.Models
{
    public enum ExamType
    {
        Quiz = 1,
        Midterm = 2,
        Final = 3,
        Viva = 4,
        Assignment = 5
    }
}
